# AMD AI Inference Lab

A personal research project for experimenting with Large Language Model (LLM) inference, model optimization, and cloud-based GPU workloads.

This repository is designed as a clean starting point for testing AI inference workflows on cloud GPU environments, including AMD GPU infrastructure.

## Project Goals

- Build simple AI inference workflows
- Test LLM prompt and response pipelines
- Prepare cloud GPU development environments
- Explore model optimization and deployment strategies
- Document experiments and performance notes

## Why GPU Computing?

Modern AI applications often require accelerated computing for faster inference, model testing, and experimentation. This project focuses on learning how AI workloads behave in a cloud environment and how GPU resources can improve development workflows.

## Planned Experiments

- Basic Python inference pipeline
- Local model loading experiment
- Prompt evaluation workflow
- GPU environment setup notes
- Performance comparison notes

## Tech Stack

- Python
- PyTorch
- Transformers
- Linux
- Cloud GPU environments
- AMD GPU / ROCm research

## Repository Structure

```text
amd-ai-inference-lab/
├── README.md
├── requirements.txt
├── src/
│   ├── main.py
│   └── prompts.py
├── experiments/
│   └── experiment_log.md
├── docs/
│   └── gpu_research_notes.md
└── .gitignore
```

## Status

This is an early-stage personal AI research project.
