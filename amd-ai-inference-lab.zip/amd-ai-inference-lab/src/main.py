from prompts import SAMPLE_PROMPTS


def run_demo() -> None:
    print("AMD AI Inference Lab")
    print("Simple prompt workflow demo\n")

    for index, prompt in enumerate(SAMPLE_PROMPTS, start=1):
        print(f"Prompt {index}: {prompt}")
        print("Status: ready for model inference experiment")
        print("-" * 60)


if __name__ == "__main__":
    run_demo()
