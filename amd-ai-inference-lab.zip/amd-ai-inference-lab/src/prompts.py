SAMPLE_PROMPTS = [
    "Explain how GPU acceleration improves AI inference.",
    "Summarize the benefits of cloud-based AI development environments.",
    "Compare CPU and GPU workloads for machine learning experiments.",
]
