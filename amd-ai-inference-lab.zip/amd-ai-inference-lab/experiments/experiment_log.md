# Experiment Log

## Experiment 001: Environment Setup

**Goal:** Prepare a basic Python environment for AI inference testing.

**Planned steps:**
1. Create Python virtual environment
2. Install PyTorch and Transformers
3. Run a simple prompt workflow
4. Document hardware and runtime observations

**Notes:**
- Future tests may include GPU-based inference and performance comparison.
- AMD GPU / ROCm compatibility will be documented when GPU access is available.
